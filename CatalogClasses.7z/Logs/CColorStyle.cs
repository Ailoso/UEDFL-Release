﻿
class CColorStyle
{
	CStringLink Name; //fieldtype: String
	SUIColorEntry[] ColorEntry //struct
	{
		C4Vector[] Value; //fieldtype: Unknown
	}
}
