﻿
class CLensFlareSet
{
	SFlareInfo[] Flare //struct
	{
		CModelLink Model; //fieldtype: CatalogLink
		CIdentifier Template; //fieldtype: String
	}
}
