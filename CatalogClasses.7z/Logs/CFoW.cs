﻿
class CFoW
{
	CColor Color; //fieldtype: Unknown
	CFixed UnhideRadius; //fieldtype: Fixed
	bool8 Expand; //fieldtype: Unknown
	bool8 Hidden; //fieldtype: Unknown
	bool8 Persistent; //fieldtype: Unknown
	int32 BlendSpeed; //fieldtype: IntSigned
}
