﻿
class CBoost
{
	CStringLink Name; //fieldtype: String
	CStringLink ShortName; //fieldtype: String
	CStringLink StoreName; //fieldtype: String
	TBattleProductId ProductId; //fieldtype: IntSigned
	CImagePath TileTexture; //fieldtype: String
	CImagePath PreviewTexture; //fieldtype: String
	THyperlinkId HyperlinkId; //fieldtype: String
	CAssetPath PreviewCutsceneFile; //fieldtype: String
	CAssetPath TileCutsceneFile; //fieldtype: String
	CStringLink StoreTypeName; //fieldtype: String
}
