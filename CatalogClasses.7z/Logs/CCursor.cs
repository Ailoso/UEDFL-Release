﻿
class CCursor
{
	CImagePath Texture; //fieldtype: String
	uint32 HotspotX; //fieldtype: IntUnsigned
	uint32 HotspotY; //fieldtype: IntUnsigned
	CImagePath Texture16; //fieldtype: String
	CImagePath Texture64; //fieldtype: String
}
