﻿
class CBeam
{
}

class CBeamSync
{
}

class CBeamSyncSweeper
{
}

class CBeamAsync
{
}

class CBeamAsyncLinear
{
	CFixed Duration; //fieldtype: Fixed
}

class CBeamAsyncShadow
{
}
