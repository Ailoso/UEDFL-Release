﻿
class CPhysicsMaterial
{
	real32 Density; //fieldtype: Float
	real32 Friction; //fieldtype: Float
	real32 Restitution; //fieldtype: Float
	real32 LinearDamping; //fieldtype: Float
	real32 AngularDamping; //fieldtype: Float
}
